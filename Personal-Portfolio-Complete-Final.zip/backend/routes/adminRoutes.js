const multer = require("multer");
const path = require("path");

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

const express = require("express");
const router = express.Router();
const Contact = require("../models/Contact");
const Project = require("../models/Project");

// Middleware to check admin password


// Get all contacts
router.get("/contacts", verifyToken, async (req, res) => {
  try {
    const contacts = await Contact.find().sort({ createdAt: -1 });
    res.json(contacts);
  } catch (err) {
    res.status(500).json({ error: "❌ Could not fetch contacts" });
  }
});

// Delete contact by ID
router.delete("/contacts/:id", verifyToken, async (req, res) => {
  try {
    await Contact.findByIdAndDelete(req.params.id);
    res.json({ message: "✅ Contact deleted" });
  } catch (err) {
    res.status(500).json({ error: "❌ Could not delete contact" });
  }
});

// Get all projects
router.get("/projects", verifyToken, async (req, res) => {
  try {
    const projects = await Project.find().sort({ createdAt: -1 });
    res.json(projects);
  } catch (err) {
    res.status(500).json({ error: "❌ Could not fetch projects" });
  }
});

// Delete project by ID
router.delete("/projects/:id", verifyToken, async (req, res) => {
  try {
    await Project.findByIdAndDelete(req.params.id);
    res.json({ message: "✅ Project deleted" });
  } catch (err) {
    res.status(500).json({ error: "❌ Could not delete project" });
  }
});



// Add new project
router.post("/projects", verifyToken, upload.single("image"), async (req, res) => {
  try {
    const { title, description, link } = req.body;
    const image = req.file ? `/uploads/${req.file.filename}` : null;

    const newProject = new Project({ title, description, link, image });
    await newProject.save();
    res.status(201).json({ message: "✅ Project added!", project: newProject });
  } catch (err) {
    res.status(500).json({ error: "❌ Could not add project" });
  }
});




// Update project
router.put("/projects/:id", verifyToken, async (req, res) => {
  try {
    const { title, description, link } = req.body;
    await Project.findByIdAndUpdate(req.params.id, { title, description, link });
    res.json({ message: "✅ Project updated!" });
  } catch (err) {
    res.status(500).json({ error: "❌ Could not update project" });
  }
});




// Reply to contact
const nodemailer = require("nodemailer");

router.post("/contacts/:id/reply", verifyToken, async (req, res) => {
  try {
    const { subject, message } = req.body;
    const contact = await Contact.findById(req.params.id);
    if (!contact) return res.status(404).json({ error: "Contact not found" });

    // Configure transporter
    let transporter = nodemailer.createTransport({
      service: "gmail", // adjust if using another email provider
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    // Send email
    await transporter.sendMail({
      from: `"Portfolio Admin" <${process.env.EMAIL_USER}>`,
      to: contact.email,
      subject,
      text: message,
    });

    res.json({ message: "✅ Reply sent successfully!" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "❌ Could not send reply" });
  }
});


module.exports = router;
