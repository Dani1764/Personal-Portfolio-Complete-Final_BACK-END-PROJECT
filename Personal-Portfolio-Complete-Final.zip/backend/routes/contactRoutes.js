const { body, validationResult } = require("express-validator");

const express = require("express");
const router = express.Router();
const rateLimit = require("express-rate-limit");
const { body, validationResult } = require("express-validator");
const Contact = require("../models/Contact");

// Limit: 5 contact submissions per 10 minutes per IP
const contactLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false
});

// POST - Save contact submission
router.post("/", [
  body("name").notEmpty(),
  body("email").isEmail(),
  body("message").notEmpty()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  try {
    const { name, email, message } = req.body;
    const newContact = new Contact({ name, email, message });
    await newContact.save();
    res.status(201).json({ message: "✅ Contact saved!" });
  } catch (err) {
    res.status(500).json({ error: "❌ Could not save contact" });
  }
});

// GET - Retrieve all contacts
router.get("/", async (req, res) => {
  try {
    const contacts = await Contact.find();
    res.json(contacts);
  } catch (err) {
    res.status(500).json({ error: "❌ Could not fetch contacts" });
  }
});

module.exports = router;
