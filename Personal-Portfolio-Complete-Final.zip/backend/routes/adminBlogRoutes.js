const express = require("express");
const router = express.Router();
const Blog = require("../models/Blog");
const multer = require("multer");
const path = require("path");
const jwt = require("jsonwebtoken");

// verify token middleware
function verifyToken(req, res, next) {
  const auth = req.headers["authorization"] || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
  if (!token) return res.status(401).json({ error: "No token" });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    return next();
  } catch (e) {
    return res.status(401).json({ error: "Invalid token" });
  }
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

// Create
router.post("/", verifyToken, upload.single("cover"), async (req, res) => {
  const { title, content } = req.body;
  const coverImage = req.file ? `/uploads/${req.file.filename}` : null;
  const blog = new Blog({ title, content, coverImage });
  await blog.save();
  res.status(201).json({ message: "Created", blog });
});

// Update
router.put("/:id", verifyToken, upload.single("cover"), async (req, res) => {
  const { title, content } = req.body;
  const update = { title, content };
  if (req.file) update.coverImage = `/uploads/${req.file.filename}`;
  await Blog.findByIdAndUpdate(req.params.id, update);
  res.json({ message: "Updated" });
});

// Delete
router.delete("/:id", verifyToken, async (req, res) => {
  await Blog.findByIdAndDelete(req.params.id);
  res.json({ message: "Deleted" });
});

module.exports = router;
