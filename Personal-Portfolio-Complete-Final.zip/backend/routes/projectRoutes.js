const express = require("express");
const router = express.Router();
const Project = require("../models/Project");

// POST - Add new project/blog
router.post("/", async (req, res) => {
  try {
    const { title, description, link } = req.body;
    const newProject = new Project({ title, description, link });
    await newProject.save();
    res.status(201).json({ message: "✅ Project added!" });
  } catch (err) {
    res.status(500).json({ error: "❌ Could not save project" });
  }
});

// GET - Fetch all projects
router.get("/", async (req, res) => {
  try {
    const projects = await Project.find();
    res.json(projects);
  } catch (err) {
    res.status(500).json({ error: "❌ Could not fetch projects" });
  }
});

module.exports = router;
