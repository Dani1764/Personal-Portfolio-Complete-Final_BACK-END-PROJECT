# Personal Portfolio Website 🚀

This is a **full-stack personal portfolio** project built with:
- **Frontend**: Plain HTML, CSS, JS (Netlify/GitHub Pages ready)
- **Backend**: Node.js + Express + MongoDB (deployed via Render/Heroku/Docker)
- **Features**:
  - 📂 Project showcase (with images & links)
  - ✉️ Contact form with backend storage + email notifications
  - 📝 Blog system with SEO-friendly slugs, WYSIWYG editor (Quill), and cover images
  - 🔐 Secure admin panel with JWT authentication
  - 🌗 Dark mode toggle across all pages
  - 🛡️ Security: Helmet, rate limiting, mongo-sanitize, validation
  - 📦 Deployment ready: Docker, GitHub Actions (CI/CD), Netlify, GitHub Pages

## Elevator Pitch 🎤
*"This project is a production-ready full-stack portfolio website.  
It highlights my projects and blogs, provides a contact form, and features an admin panel with JWT-based authentication for managing content.  
The site is fully responsive, SEO-optimized, secured with best practices, and comes with automated deployment pipelines to Netlify, GitHub Pages, Render, or Heroku."*

## Quick Start

### Backend (Local)
```bash
cd backend
cp .env.example .env   # configure MONGO_URI, ADMIN_PASSWORD, JWT_SECRET, EMAIL creds
npm install
npm start
```

### Backend (Docker)
```bash
docker compose up --build
```

### Frontend
- Serve via Netlify or GitHub Pages
- Update `API_BASE` in HTML files to point to your backend URL

### Deployment (CI/CD)
- **Netlify**: Frontend auto-deploy via GitHub Actions
- **GitHub Pages**: Fallback auto-deploy workflow included
- **Render/Heroku**: Backend deploy supported via GitHub Actions

## Folder Structure
```
backend/       # Express + MongoDB backend
.github/       # GitHub Actions workflows (CI/CD)
uploads/       # Uploaded images
index.html     # Frontend entry point
blogs.html     # Blogs listing page
blog.html      # Blog detail page
admin.html     # Admin panel
```

---

⚡ Ready to run, deploy, and showcase! 
